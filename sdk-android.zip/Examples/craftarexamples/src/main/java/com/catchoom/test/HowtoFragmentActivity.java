package com.catchoom.test;

import android.os.Bundle;
import android.app.Activity;

public class HowtoFragmentActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_howto_fragment);
    }

}
